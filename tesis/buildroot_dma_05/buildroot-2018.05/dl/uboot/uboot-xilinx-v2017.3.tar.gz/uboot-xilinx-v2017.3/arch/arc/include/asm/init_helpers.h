/*
 * Copyright (C) 2013-2015 Synopsys, Inc. All rights reserved.
 *
 * SPDX-License-Identifier:	GPL-2.0+
 */

#ifndef _ASM_ARC_INIT_HELPERS_H
#define _ASM_ARC_INIT_HELPERS_H

int init_cache_f_r(void);

#endif	/* _ASM_ARC_INIT_HELPERS_H */

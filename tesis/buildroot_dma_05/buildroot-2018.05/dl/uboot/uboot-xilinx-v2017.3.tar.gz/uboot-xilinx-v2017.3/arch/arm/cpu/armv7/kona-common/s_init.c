/*
 * Copyright 2014 Broadcom Corporation.
 *
 * SPDX-License-Identifier:	GPL-2.0+
 */

/*
 * Early system init. Currently empty.
 */
void s_init(void)
{
}
